O HTML ser executado é o "SiteDoEspaço.html"

O objetivo deste trabalho tem em vista a reformulação do site
de Charles Ostman e torna-lo mobile friendly.

Assim para chegar a este objetivo, o site foi feito sob a 
base de grids que facilitam a organização do site e a disposição
da informação nas paginas reformuladas.

As paginas reformoladas foram: a pagina inicial, content, archive, tech e mission

Para tornar o site responsive recorreu-se ao uso do comando @media
e há seleção de 3 break points que representam a dimensão dos ecrãs
que pretendemos que o site mude a sua forma. 

1ª Dimensão escolhida: max 575px
2ª Dimensão escolhida: min 576px max 992px
3ª Dimensão escolhida: min 993px

/*max575 576-> 992 993